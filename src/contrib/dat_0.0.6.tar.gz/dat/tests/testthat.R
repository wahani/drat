library(testthat)
library(dat)

test_check("dat")
