# Notes:
# - Need to import data.table so dplyr functions can handle that format. If not
# I get obscure error messages from dplyr functions.

#' @importFrom magrittr %>% %<>%
#' @importFrom stats as.formula
#' @import methods
#' @import aoos
#' @import data.table
#' @import tibble
NULL
